const express = require('express');
const router = express.Router();
const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();
const { chatWithAI, getStudyAdvice } = require('../services/aiAssistant');

router.get('/subjects/:userId', async (req, res) => {
  try {
    const subjects = await prisma.subject.findMany({
      where: { userId: req.params.userId },
      include: { studySessions: true },
    });
    res.json(subjects);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.post('/subjects', async (req, res) => {
  try {
    const { userId, name, examDate, weeklyGoal } = req.body;
    const subject = await prisma.subject.create({
      data: {
        userId,
        name,
        examDate: examDate ? new Date(examDate) : null,
        weeklyGoal: weeklyGoal || 5.0,
      },
    });
    res.status(201).json(subject);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.post('/sessions', async (req, res) => {
  try {
    const { subjectId, duration } = req.body;
    const session = await prisma.studySession.create({
      data: { subjectId, duration: parseInt(duration) },
    });
    res.status(201).json(session);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.get('/stats/:userId', async (req, res) => {
  try {
    const weekAgo = new Date();
    weekAgo.setDate(weekAgo.getDate() - 7);

    const subjects = await prisma.subject.findMany({
      where: { userId: req.params.userId },
      include: {
        studySessions: { where: { date: { gte: weekAgo } } },
      },
    });

    const stats = subjects.map(s => ({
      name: s.name,
      minutesThisWeek: s.studySessions.reduce((sum, ss) => sum + ss.duration, 0),
      goalMinutes: s.weeklyGoal * 60,
      examDate: s.examDate,
    }));

    res.json(stats);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.post('/advice/:userId', async (req, res) => {
  try {
    const advice = await getStudyAdvice(req.params.userId);
    res.json(advice);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.post('/chat', async (req, res) => {
  try {
    const { message, userId } = req.body;
    const reply = await chatWithAI(message, userId);
    res.json({ reply });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
