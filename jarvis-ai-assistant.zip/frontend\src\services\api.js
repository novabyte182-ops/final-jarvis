import { io } from 'socket.io-client';

const API_BASE = import.meta.env.VITE_API_URL || '';

export const api = {
  async get(path) {
    const res = await fetch(`${API_BASE}/api${path}`);
    return res.json();
  },
  async post(path, data) {
    const res = await fetch(`${API_BASE}/api${path}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    return res.json();
  },
  async patch(path, data) {
    const res = await fetch(`${API_BASE}/api${path}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    return res.json();
  },
  async delete(path) {
    const res = await fetch(`${API_BASE}/api${path}`, {
      method: 'DELETE',
    });
    return res.json();
  },
};

export const socket = io(import.meta.env.VITE_API_URL || window.location.origin);
