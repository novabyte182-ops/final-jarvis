run = "cd backend && npm install && npx prisma db push && node src/server.js"

[deployment]
run = ["sh", "-c", "cd backend && npm install && npx prisma db push && node src/server.js"]

[[ports]]
localPort = 3000
externalPort = 3000

[env]
PORT = "3000"
NODE_ENV = "production"
AI_PROVIDER = "openrouter"
DATABASE_URL = "file:./dev.db"
PRAYER_CALC_METHOD = "2"
DEFAULT_CITY = "Dhaka"
DEFAULT_COUNTRY = "Bangladesh"
