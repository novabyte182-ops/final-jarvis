const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function chatWithAI(message, userId = null) {
  let userContext = '';

  if (userId) {
    try {
      const user = await prisma.user.findUnique({
        where: { id: userId },
        include: {
          tasks: { where: { completed: false }, take: 5 },
          subjects: { take: 5 },
        },
      });

      if (user) {
        const pendingTasks = user.tasks.map(t => `- ${t.title} (due: ${new Date(t.dueDate).toLocaleDateString()}, priority: ${t.priority})`).join('\n');
        const subjects = user.subjects.map(s => `- ${s.name}`).join('\n');
        userContext = `\nUser's Pending Tasks:\n${pendingTasks || 'None'}\n\nUser's Subjects:\n${subjects || 'None'}`;
      }
    } catch (e) {
      console.error('Error fetching user context:', e.message);
    }
  }

  const systemPrompt = `You are Jarvis, a helpful AI assistant for university students. Your role:

1. Help manage daily tasks and study schedules
2. Track 5 daily prayers (Fajr, Dhuhr, Asr, Maghrib, Isha) and remind the user
3. Answer academic questions and explain concepts clearly
4. Provide encouragement and motivation
5. Be respectful, concise, and friendly

Always greet with "Assalamualaikum" if the conversation is just starting.
Use simple language and give actionable advice.
If asked about prayers, reference the prayer schedule.
If asked about studying, consider deadlines and priorities.${userContext}`;

  try {
    const provider = process.env.AI_PROVIDER || 'openrouter';

    if (provider === 'huggingface' && process.env.HF_TOKEN) {
      return await callHuggingFace(systemPrompt, message);
    } else {
      return await callOpenRouter(systemPrompt, message);
    }
  } catch (err) {
    console.error('AI Error:', err.message);
    return `I understand your message: "${message}". My AI service is currently unavailable. Please check your API keys or try again later. In the meantime, I can still help manage your tasks and prayers through the dashboard!`;
  }
}

async function callOpenRouter(systemPrompt, message) {
  const res = await fetch('https://openrouter.ai/api/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${process.env.OPENROUTER_KEY}`,
      'Content-Type': 'application/json',
      'HTTP-Referer': 'https://jarvis-assistant.app',
      'X-Title': 'Jarvis AI Assistant',
    },
    body: JSON.stringify({
      model: 'meta-llama/llama-3-8b-instruct:free',
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: message },
      ],
      max_tokens: 500,
      temperature: 0.7,
    }),
  });

  if (!res.ok) {
    const errText = await res.text();
    throw new Error(`OpenRouter API error: ${res.status} - ${errText}`);
  }

  const data = await res.json();
  return data.choices?.[0]?.message?.content || 'No response generated.';
}

async function callHuggingFace(systemPrompt, message) {
  const res = await fetch('https://api-inference.huggingface.co/models/HuggingFaceH4/zephyr-7b-beta', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${process.env.HF_TOKEN}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      inputs: `<|system|>${systemPrompt}</s>\n<|user|>${message}</s>\n<|assistant|>`,
      parameters: { max_new_tokens: 500, temperature: 0.7 },
    }),
  });

  if (!res.ok) throw new Error(`HuggingFace API error: ${res.status}`);

  const data = await res.json();
  return data?.[0]?.generated_text?.split('<|assistant|>').pop()?.trim() || 'No response generated.';
}

async function getStudyAdvice(userId) {
  try {
    const user = await prisma.user.findUnique({
      where: { id: userId },
      include: {
        subjects: {
          include: { studySessions: true },
        },
        tasks: { where: { completed: false } },
      },
    });

    if (!user) return { advice: 'Please set up your profile first.' };

    let advice = `Here's your personalized study plan:\n\n`;

    for (const subject of user.subjects) {
      const totalMinutes = subject.studySessions.reduce((sum, s) => sum + s.duration, 0);
      const hours = (totalMinutes / 60).toFixed(1);
      const remaining = Math.max(0, subject.weeklyGoal - totalMinutes / 60);
      advice += `📚 ${subject.name}: ${hours}h studied this week (${remaining}h remaining of ${subject.weeklyGoal}h goal)\n`;
    }

    if (user.tasks.length > 0) {
      advice += `\n⚡ Pending tasks (sorted by priority):\n`;
      const sorted = user.tasks.sort((a, b) => {
        const order = { High: 0, Medium: 1, Low: 2 };
        return (order[a.priority] || 1) - (order[b.priority] || 1);
      });
      sorted.slice(0, 5).forEach(t => {
        advice += `• ${t.title} (${t.priority}) - Due: ${new Date(t.dueDate).toLocaleDateString()}\n`;
      });
    }

    return { advice };
  } catch (err) {
    console.error('Study advice error:', err.message);
    return { advice: 'Could not generate study advice. Please try again.' };
  }
}

module.exports = { chatWithAI, getStudyAdvice };
