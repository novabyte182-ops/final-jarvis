# Jarvis AI Assistant

A voice-enabled AI assistant for university students that manages daily tasks, schedules 5 daily prayers (namaz), and helps with study planning.

## Features
- Task Manager with Kanban board
- Namaz Scheduler (Aladhan API)
- Study Planner with Pomodoro timer
- Voice Commands (Web Speech API)
- AI Chat (HuggingFace / OpenRouter)
- PWA + Mobile (Capacitor)

## Quick Start

### Backend
```bash
cd backend
npm install
npx prisma db push
npm run dev
```

### Frontend
```bash
cd frontend
npm install
npm run dev
```

### Mobile (APK)
```bash
npx cap sync
npx cap open android
```

## Tech Stack
- Frontend: React + Vite + Tailwind CSS
- Backend: Node.js + Express + Socket.IO
- Database: SQLite (dev) / PostgreSQL (prod via Prisma)
- AI: HuggingFace / OpenRouter (free tier)
- Voice: Web Speech API (free, built-in)
- Prayer Times: Aladhan API (free)
