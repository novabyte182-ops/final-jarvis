import { io } from 'socket.io-client';

const getApiBase = () => {
  if (import.meta.env.VITE_API_URL) return import.meta.env.VITE_API_URL;
  if (typeof window !== 'undefined') {
    const hostname = window.location.hostname;
    if (hostname.includes('replit.dev') || hostname.includes('repl.co')) {
      return window.location.origin;
    }
  }
  return '';
};

const API_BASE = getApiBase();

export const api = {
  async get(path) {
    const res = await fetch(`${API_BASE}/api${path}`);
    return res.json();
  },
  async post(path, data) {
    const res = await fetch(`${API_BASE}/api${path}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    return res.json();
  },
  async patch(path, data) {
    const res = await fetch(`${API_BASE}/api${path}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    return res.json();
  },
  async delete(path) {
    const res = await fetch(`${API_BASE}/api${path}`, {
      method: 'DELETE',
    });
    return res.json();
  },
};

export const socket = io(API_BASE || window.location.origin, {
  autoConnect: true,
  reconnection: true,
  reconnectionDelay: 1000,
  reconnectionAttempts: 5,
});
