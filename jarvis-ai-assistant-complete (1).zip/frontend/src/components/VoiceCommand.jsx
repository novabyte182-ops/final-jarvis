import { useState, useEffect } from 'react';
import { VoiceController } from '../services/voice';
import { api } from '../services/api';

const Mic = () => (
  <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 1a3 3 0 00-3 3v8a3 3 0 006 0V4a3 3 0 00-3-3z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 10v2a7 7 0 01-14 0v-2" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19v4m-4 0h8" /></svg>
);

const MicOff = () => (
  <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 1a3 3 0 00-3 3v8a3 3 0 006 0V4a3 3 0 00-3-3z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 10v2a7 7 0 01-14 0v-2" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19v4m-4 0h8" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 3l18 18" /></svg>
);

export default function VoiceCommand({ userId, onResult }) {
  const [listening, setListening] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [interim, setInterim] = useState('');
  const [response, setResponse] = useState('');
  const [processing, setProcessing] = useState(false);
  const [supported, setSupported] = useState(true);
  const [commandHistory, setCommandHistory] = useState([]);

  const voiceController = new VoiceController({
    onResult: async (text) => {
      setTranscript(text);
      setInterim('');
      setListening(false);
      setProcessing(true);

      try {
        const result = await api.post('/voice/process', { text, userId });
        setResponse(result.response);
        voiceController.speak(result.response);
        setCommandHistory(prev => [{ text, response: result.response, time: new Date() }, ...prev].slice(0, 10));
        if (onResult) onResult(result);
      } catch (err) {
        setResponse('Sorry, I could not process that command.');
      }

      setProcessing(false);
    },
    onStart: () => {
      setListening(true);
      setTranscript('');
      setInterim('');
      setResponse('');
    },
    onEnd: () => setListening(false),
    onInterim: (text) => setInterim(text),
  });

  useEffect(() => {
    if (!voiceController.isSupported) {
      setSupported(false);
    }
  }, []);

  const toggleListening = () => {
    if (listening) {
      voiceController.stop();
    } else {
      voiceController.start();
    }
  };

  const commands = [
    { phrase: '"Add task submit physics report"', action: 'Creates a new task' },
    { phrase: '"Show my tasks"', action: 'Lists pending tasks' },
    { phrase: '"Next prayer time"', action: 'Shows countdown to next prayer' },
    { phrase: '"Mark dhuhr as done"', action: 'Marks prayer as completed' },
    { phrase: '"Start pomodoro"', action: 'Starts study timer' },
    { phrase: '"What should I study?"', action: 'Gets AI study advice' },
  ];

  if (!supported) {
    return (
      <div className="glass-card rounded-2xl p-6 text-center">
        <p className="text-yellow-400">Voice commands are not supported in this browser.</p>
        <p className="text-jarvis-muted text-sm mt-2">Try using Chrome or Edge for the best experience.</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="text-center">
        <button
          onClick={toggleListening}
          className={`w-24 h-24 rounded-full flex items-center justify-center transition-all duration-300 ${
            listening
              ? 'bg-red-500 text-white listening-pulse scale-110'
              : processing
              ? 'bg-jarvis-accent/50 text-white animate-pulse'
              : 'bg-jarvis-accent hover:bg-jarvis-accentHover text-white hover:scale-105'
          }`}
        >
          {listening ? <Mic /> : processing ? (
            <div className="flex gap-1">
              <span className="w-2 h-2 bg-white rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
              <span className="w-2 h-2 bg-white rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
              <span className="w-2 h-2 bg-white rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
            </div>
          ) : <MicOff />}
        </button>
        <p className="mt-4 text-lg font-medium">
          {listening ? 'Listening...' : processing ? 'Processing...' : 'Tap to speak'}
        </p>
      </div>

      {(transcript || interim) && (
        <div className="glass-card rounded-xl p-4">
          <p className="text-jarvis-muted text-xs uppercase tracking-wide mb-1">You said:</p>
          <p className="text-lg font-medium">{transcript || interim}</p>
        </div>
      )}

      {response && (
        <div className="bg-jarvis-accent/10 border border-jarvis-accent/20 rounded-xl p-4">
          <p className="text-jarvis-accent text-xs uppercase tracking-wide mb-1">Jarvis:</p>
          <p className="text-sm leading-relaxed">{response}</p>
        </div>
      )}

      <div className="glass-card rounded-xl p-4">
        <h3 className="font-semibold text-sm mb-3">Voice Commands</h3>
        <div className="grid sm:grid-cols-2 gap-2">
          {commands.map((cmd, i) => (
            <div key={i} className="bg-jarvis-dark/50 rounded-lg p-3">
              <p className="text-jarvis-accent text-xs font-mono">{cmd.phrase}</p>
              <p className="text-jarvis-muted text-xs mt-1">{cmd.action}</p>
            </div>
          ))}
        </div>
      </div>

      {commandHistory.length > 0 && (
        <div className="glass-card rounded-xl p-4">
          <h3 className="font-semibold text-sm mb-3">Recent Commands</h3>
          <div className="space-y-2">
            {commandHistory.map((cmd, i) => (
              <div key={i} className="bg-jarvis-dark/50 rounded-lg p-3">
                <p className="text-sm">"{cmd.text}"</p>
                <p className="text-jarvis-muted text-xs mt-1">{cmd.response}</p>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
