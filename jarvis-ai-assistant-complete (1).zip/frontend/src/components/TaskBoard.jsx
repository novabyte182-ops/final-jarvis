import { useState, useEffect } from 'react';
import { api } from '../services/api';

const Plus = () => (
  <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" /></svg>
);

const Trash = () => (
  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
);

const Check = () => (
  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" /></svg>
);

export default function TaskBoard({ userId }) {
  const [tasks, setTasks] = useState([]);
  const [showAdd, setShowAdd] = useState(false);
  const [newTask, setNewTask] = useState({ title: '', category: 'Personal', priority: 'Medium', dueDate: '' });
  const [filter, setFilter] = useState('all');

  useEffect(() => {
    loadTasks();
  }, [userId]);

  const loadTasks = async () => {
    const data = await api.get(`/tasks/${userId}`);
    setTasks(data);
  };

  const addTask = async () => {
    if (!newTask.title.trim()) return;
    await api.post('/tasks', { userId, ...newTask, dueDate: newTask.dueDate || new Date() });
    setNewTask({ title: '', category: 'Personal', priority: 'Medium', dueDate: '' });
    setShowAdd(false);
    loadTasks();
  };

  const toggleComplete = async (task) => {
    await api.patch(`/tasks/${task.id}`, { completed: !task.completed });
    loadTasks();
  };

  const deleteTask = async (id) => {
    await api.delete(`/tasks/${id}`);
    loadTasks();
  };

  const filteredTasks = filter === 'all'
    ? tasks
    : filter === 'pending'
    ? tasks.filter(t => !t.completed)
    : tasks.filter(t => t.completed);

  const columns = [
    { key: 'High', label: 'High Priority', color: 'border-red-500' },
    { key: 'Medium', label: 'Medium Priority', color: 'border-yellow-500' },
    { key: 'Low', label: 'Low Priority', color: 'border-green-500' },
  ];

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <h2 className="text-2xl font-bold">Task Manager</h2>
        <div className="flex gap-2">
          {['all', 'pending', 'completed'].map(f => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`px-3 py-1.5 rounded-lg text-sm capitalize transition-all ${
                filter === f ? 'bg-jarvis-accent text-white' : 'bg-jarvis-card text-jarvis-muted hover:text-jarvis-text'
              }`}
            >
              {f}
            </button>
          ))}
          <button
            onClick={() => setShowAdd(!showAdd)}
            className="flex items-center gap-2 px-4 py-1.5 bg-jarvis-accent hover:bg-jarvis-accentHover rounded-lg text-sm font-medium transition-all"
          >
            <Plus /> Add Task
          </button>
        </div>
      </div>

      {showAdd && (
        <div className="glass-card rounded-xl p-4 space-y-3">
          <input
            type="text"
            placeholder="Task title..."
            value={newTask.title}
            onChange={e => setNewTask({ ...newTask, title: e.target.value })}
            className="w-full bg-jarvis-dark border border-jarvis-accent/20 rounded-lg px-4 py-2.5 text-sm focus:outline-none focus:border-jarvis-accent"
          />
          <div className="flex flex-wrap gap-3">
            <select
              value={newTask.category}
              onChange={e => setNewTask({ ...newTask, category: e.target.value })}
              className="bg-jarvis-dark border border-jarvis-accent/20 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-jarvis-accent"
            >
              <option>Personal</option>
              <option>Assignment</option>
              <option>Exam</option>
              <option>Health</option>
              <option>Other</option>
            </select>
            <select
              value={newTask.priority}
              onChange={e => setNewTask({ ...newTask, priority: e.target.value })}
              className="bg-jarvis-dark border border-jarvis-accent/20 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-jarvis-accent"
            >
              <option>High</option>
              <option>Medium</option>
              <option>Low</option>
            </select>
            <input
              type="date"
              value={newTask.dueDate}
              onChange={e => setNewTask({ ...newTask, dueDate: e.target.value })}
              className="bg-jarvis-dark border border-jarvis-accent/20 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-jarvis-accent"
            />
            <button
              onClick={addTask}
              className="px-4 py-2 bg-jarvis-accent hover:bg-jarvis-accentHover rounded-lg text-sm font-medium transition-all"
            >
              Create
            </button>
          </div>
        </div>
      )}

      <div className="grid md:grid-cols-3 gap-4">
        {columns.map(col => {
          const columnTasks = filteredTasks.filter(t => t.priority === col.key);
          return (
            <div key={col.key} className={`bg-jarvis-card/50 rounded-xl border-t-4 ${col.color} p-4`}>
              <h3 className="font-semibold text-sm mb-3">{col.label} ({columnTasks.length})</h3>
              <div className="space-y-2">
                {columnTasks.map(task => (
                  <div
                    key={task.id}
                    className={`p-3 bg-jarvis-dark/50 rounded-lg border border-jarvis-accent/5 transition-all ${
                      task.completed ? 'opacity-50' : ''
                    }`}
                  >
                    <div className="flex items-start gap-2">
                      <button
                        onClick={() => toggleComplete(task)}
                        className={`mt-0.5 w-5 h-5 rounded-full border-2 flex items-center justify-center flex-shrink-0 ${
                          task.completed
                            ? 'bg-jarvis-success border-jarvis-success'
                            : 'border-jarvis-muted/50 hover:border-jarvis-accent'
                        }`}
                      >
                        {task.completed && <Check />}
                      </button>
                      <div className="flex-1 min-w-0">
                        <p className={`text-sm font-medium ${task.completed ? 'line-through text-jarvis-muted' : ''}`}>
                          {task.title}
                        </p>
                        <div className="flex items-center gap-2 mt-1">
                          <span className="text-xs text-jarvis-muted">{task.category}</span>
                          {task.dueDate && (
                            <span className="text-xs text-jarvis-muted">
                              Due: {new Date(task.dueDate).toLocaleDateString()}
                            </span>
                          )}
                        </div>
                      </div>
                      <button
                        onClick={() => deleteTask(task.id)}
                        className="text-jarvis-muted hover:text-red-400 transition-colors p-1"
                      >
                        <Trash />
                      </button>
                    </div>
                  </div>
                ))}
                {columnTasks.length === 0 && (
                  <p className="text-jarvis-muted text-xs text-center py-4">No tasks</p>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
