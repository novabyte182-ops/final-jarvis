import { useState, useRef, useEffect } from 'react';
import { api } from '../services/api';
import { VoiceController } from '../services/voice';

const Send = () => (
  <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" /></svg>
);

const Mic = () => (
  <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 1a3 3 0 00-3 3v8a3 3 0 006 0V4a3 3 0 00-3-3z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 10v2a7 7 0 01-14 0v-2" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19v4m-4 0h8" /></svg>
);

const Bot = () => (
  <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" /></svg>
);

const User = () => (
  <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" /></svg>
);

const suggestedPrompts = [
  "What should I study next?",
  "Help me create a study schedule",
  "Explain quantum physics simply",
  "Remind me about my tasks",
  "When is my next prayer?",
  "Give me study tips for exams",
];

export default function ChatInterface({ userId }) {
  const [messages, setMessages] = useState([
    { role: 'assistant', content: "Assalamualaikum! I'm Jarvis, your AI assistant. I can help you with tasks, prayer scheduling, study planning, and answering academic questions. How can I help you today?" }
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [voiceListening, setVoiceListening] = useState(false);
  const messagesEndRef = useRef(null);
  const inputRef = useRef(null);
  const voiceRef = useRef(null);
  const loadingRef = useRef(false);

  const sendMessage = async (text) => {
    const messageText = text || input;
    if (!messageText.trim() || loadingRef.current) return;

    const userMessage = { role: 'user', content: messageText };
    setMessages(prev => [...prev, userMessage]);
    setInput('');
    loadingRef.current = true;
    setLoading(true);

    try {
      const history = messages.slice(1).map(m => ({ role: m.role, content: m.content }));
      const data = await api.post('/study/chat', { message: messageText, userId, history });
      const assistantMessage = { role: 'assistant', content: data.reply };
      setMessages(prev => [...prev, assistantMessage]);
      if (voiceRef.current) voiceRef.current.speak(data.reply);
    } catch (err) {
      setMessages(prev => [...prev, { role: 'assistant', content: 'Sorry, I encountered an error. Please try again.' }]);
    }

    loadingRef.current = false;
    setLoading(false);
  };

  if (!voiceRef.current) {
    voiceRef.current = new VoiceController({
      onResult: (text) => {
        setInput(text);
        setVoiceListening(false);
        sendMessage(text);
      },
      onStart: () => setVoiceListening(true),
      onEnd: () => setVoiceListening(false),
    });
  }

  const voiceController = voiceRef.current;

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSubmit = (e) => {
    e.preventDefault();
    sendMessage();
  };

  return (
    <div className="flex flex-col h-[calc(100vh-8rem)]">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-2xl font-bold flex items-center gap-2"><Bot /> AI Chat</h2>
        <button
          onClick={() => voiceListening ? voiceController.stop() : voiceController.start()}
          className={`p-2 rounded-lg transition-all ${
            voiceListening ? 'bg-red-500/20 text-red-400 animate-pulse' : 'bg-jarvis-card hover:bg-jarvis-accent/20'
          }`}
          title="Voice input"
        >
          <Mic />
        </button>
      </div>

      {messages.length === 1 && (
        <div className="mb-4">
          <p className="text-jarvis-muted text-sm mb-2">Try asking:</p>
          <div className="flex flex-wrap gap-2">
            {suggestedPrompts.map(prompt => (
              <button
                key={prompt}
                onClick={() => sendMessage(prompt)}
                className="bg-jarvis-card hover:bg-jarvis-accent/20 border border-jarvis-accent/10 rounded-lg px-3 py-1.5 text-sm transition-all"
              >
                {prompt}
              </button>
            ))}
          </div>
        </div>
      )}

      <div className="flex-1 overflow-y-auto space-y-4 mb-4 pr-2">
        {messages.map((msg, i) => (
          <div key={i} className={`flex gap-3 ${msg.role === 'user' ? 'justify-end' : ''}`}>
            {msg.role === 'assistant' && (
              <div className="w-8 h-8 bg-jarvis-accent/20 rounded-full flex items-center justify-center flex-shrink-0 text-jarvis-accent">
                <Bot />
              </div>
            )}
            <div
              className={`max-w-[80%] rounded-xl px-4 py-3 text-sm leading-relaxed ${
                msg.role === 'user'
                  ? 'bg-jarvis-accent text-white'
                  : 'bg-jarvis-card border border-jarvis-accent/10'
              }`}
            >
              {msg.content.split('\n').map((line, j) => (
                <p key={j} className={j > 0 ? 'mt-2' : ''}>{line}</p>
              ))}
            </div>
            {msg.role === 'user' && (
              <div className="w-8 h-8 bg-jarvis-dark rounded-full flex items-center justify-center flex-shrink-0 text-jarvis-muted">
                <User />
              </div>
            )}
          </div>
        ))}
        {loading && (
          <div className="flex gap-3">
            <div className="w-8 h-8 bg-jarvis-accent/20 rounded-full flex items-center justify-center flex-shrink-0 text-jarvis-accent">
              <Bot />
            </div>
            <div className="bg-jarvis-card border border-jarvis-accent/10 rounded-xl px-4 py-3">
              <div className="flex gap-1">
                <span className="w-2 h-2 bg-jarvis-muted/50 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                <span className="w-2 h-2 bg-jarvis-muted/50 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                <span className="w-2 h-2 bg-jarvis-muted/50 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
              </div>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      <form onSubmit={handleSubmit} className="flex gap-2">
        <input
          ref={inputRef}
          type="text"
          value={input}
          onChange={e => setInput(e.target.value)}
          placeholder="Ask Jarvis anything..."
          className="flex-1 bg-jarvis-card border border-jarvis-accent/20 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-jarvis-accent placeholder:text-jarvis-muted/50"
        />
        <button
          type="submit"
          disabled={loading || !input.trim()}
          className="px-4 py-3 bg-jarvis-accent hover:bg-jarvis-accentHover disabled:opacity-50 disabled:cursor-not-allowed rounded-xl transition-all"
        >
          <Send />
        </button>
      </form>
    </div>
  );
}
