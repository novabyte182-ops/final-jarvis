#!/bin/bash
cd /home/runner/workspace/backend && DATABASE_URL="file:./dev.db" node src/server.js &
cd /home/runner/workspace/frontend && npm run dev
