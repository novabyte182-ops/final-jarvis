const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function main() {
  console.log('Seeding database...');

  const user = await prisma.user.upsert({
    where: { id: 'demo-user' },
    update: {},
    create: {
      id: 'demo-user',
      name: 'Student',
      city: 'Dhaka',
      country: 'Bangladesh',
    },
  });

  const subjects = [
    { name: 'Physics 101', weeklyGoal: 6, examDate: new Date('2026-06-15') },
    { name: 'Calculus II', weeklyGoal: 5, examDate: new Date('2026-06-20') },
    { name: 'Computer Science 202', weeklyGoal: 8, examDate: new Date('2026-06-10') },
    { name: 'English Literature', weeklyGoal: 3, examDate: new Date('2026-06-25') },
  ];

  for (const sub of subjects) {
    await prisma.subject.upsert({
      where: { id: `subject-${sub.name.replace(/\s/g, '-').toLowerCase()}` },
      update: {},
      create: {
        id: `subject-${sub.name.replace(/\s/g, '-').toLowerCase()}`,
        name: sub.name,
        weeklyGoal: sub.weeklyGoal,
        examDate: sub.examDate,
        userId: user.id,
      },
    });
  }

  const tasks = [
    { title: 'Complete Physics Chapter 5 homework', category: 'Assignment', priority: 'High', dueDate: new Date(Date.now() + 2 * 24 * 60 * 60 * 1000) },
    { title: 'Review Calculus notes for midterm', category: 'Exam', priority: 'High', dueDate: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000) },
    { title: 'Read English Lit - Hamlet Act 3', category: 'Assignment', priority: 'Medium', dueDate: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000) },
    { title: 'Update resume for internship', category: 'Personal', priority: 'Low', dueDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000) },
    { title: 'Go for 30min run', category: 'Health', priority: 'Medium', dueDate: new Date(Date.now() + 1 * 24 * 60 * 60 * 1000) },
  ];

  for (const task of tasks) {
    await prisma.task.create({
      data: { ...task, userId: user.id },
    });
  }

  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const prayerNames = ['fajr', 'dhuhr', 'asr', 'maghrib', 'isha'];
  const prayerTimes = { fajr: '04:32', dhuhr: '12:05', asr: '15:45', maghrib: '18:22', isha: '19:50' };

  for (const name of prayerNames) {
    await prisma.prayerRecord.create({
      data: {
        userId: user.id,
        name,
        time: prayerTimes[name],
        date: today,
      },
    });
  }

  console.log('Seed complete!');
  console.log(`  User: ${user.name} (${user.id})`);
  console.log(`  Subjects: ${subjects.length}`);
  console.log(`  Tasks: ${tasks.length}`);
  console.log(`  Prayer records: ${prayerNames.length}`);
}

main()
  .catch((e) => {
    console.error('Seed error:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
