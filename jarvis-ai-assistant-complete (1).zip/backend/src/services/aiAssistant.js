const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function chatWithAI(message, userId = null, conversationHistory = []) {
  let userContext = '';

  if (userId) {
    try {
      const user = await prisma.user.findUnique({
        where: { id: userId },
        include: {
          tasks: { where: { completed: false }, take: 5, orderBy: { dueDate: 'asc' } },
          subjects: { take: 5 },
        },
      });

      if (user) {
        const pendingTasks = user.tasks.map(t =>
          `- ${t.title} (due: ${new Date(t.dueDate).toLocaleDateString()}, priority: ${t.priority})`
        ).join('\n');
        const subjects = user.subjects.map(s => `- ${s.name}`).join('\n');
        userContext = `\n\nUser Context:\nPending Tasks:\n${pendingTasks || 'None'}\nSubjects:\n${subjects || 'None'}`;
      }
    } catch (e) {
      console.error('Error fetching user context:', e.message);
    }
  }

  const systemPrompt = `You are Jarvis, a smart and friendly AI assistant for university students. Your responsibilities:

1. Help manage daily tasks, deadlines, and study schedules
2. Track 5 daily Islamic prayers (Fajr, Dhuhr, Asr, Maghrib, Isha) and send reminders
3. Answer academic questions clearly and concisely
4. Provide study tips, motivation, and encouragement
5. Be respectful, supportive, and culturally aware

Always greet with "Assalamualaikum" at the start of a new conversation.
Keep responses concise and actionable. Use bullet points for lists.
If asked about prayers, reference the user's prayer schedule.
If asked about studying, consider upcoming deadlines and subject priorities.${userContext}`;

  try {
    if (!process.env.OPENAI_API_KEY) {
      throw new Error('OPENAI_API_KEY is not set');
    }
    return await callOpenRouter(systemPrompt, message, conversationHistory);
  } catch (err) {
    console.error('AI Error:', err.message);
    return `I'm having trouble connecting right now. Please try again in a moment. In the meantime, you can manage your tasks and prayers through the dashboard!`;
  }
}

async function callOpenRouter(systemPrompt, message, conversationHistory = []) {
  const messages = [
    { role: 'system', content: systemPrompt },
    ...conversationHistory.slice(-10),
    { role: 'user', content: message },
  ];

  const res = await fetch('https://openrouter.ai/api/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`,
      'Content-Type': 'application/json',
      'HTTP-Referer': 'https://jarvis-assistant.replit.app',
      'X-Title': 'Jarvis AI Assistant',
    },
    body: JSON.stringify({
      model: 'openai/gpt-4o-mini',
      messages,
      max_tokens: 600,
      temperature: 0.7,
    }),
  });

  if (!res.ok) {
    const errText = await res.text();
    throw new Error(`OpenRouter API error: ${res.status} - ${errText}`);
  }

  const data = await res.json();
  return data.choices?.[0]?.message?.content?.trim() || 'No response generated.';
}

async function getStudyAdvice(userId) {
  try {
    const user = await prisma.user.findUnique({
      where: { id: userId },
      include: {
        subjects: { include: { studySessions: true } },
        tasks: { where: { completed: false } },
      },
    });

    if (!user) return { advice: 'Please set up your profile first.' };

    let advice = `Here's your personalized study plan:\n\n`;

    for (const subject of user.subjects) {
      const totalMinutes = subject.studySessions.reduce((sum, s) => sum + s.duration, 0);
      const hours = (totalMinutes / 60).toFixed(1);
      const remaining = Math.max(0, subject.weeklyGoal - totalMinutes / 60);
      advice += `📚 ${subject.name}: ${hours}h studied this week (${remaining.toFixed(1)}h remaining of ${subject.weeklyGoal}h goal)\n`;
    }

    if (user.tasks.length > 0) {
      advice += `\n⚡ Pending tasks:\n`;
      const sorted = user.tasks.sort((a, b) => {
        const order = { High: 0, Medium: 1, Low: 2 };
        return (order[a.priority] || 1) - (order[b.priority] || 1);
      });
      sorted.slice(0, 5).forEach(t => {
        advice += `• ${t.title} (${t.priority}) - Due: ${new Date(t.dueDate).toLocaleDateString()}\n`;
      });
    }

    return { advice };
  } catch (err) {
    console.error('Study advice error:', err.message);
    return { advice: 'Could not generate study advice. Please try again.' };
  }
}

module.exports = { chatWithAI, getStudyAdvice };
