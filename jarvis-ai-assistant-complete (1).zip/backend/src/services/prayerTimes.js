async function fetchPrayerTimes(city, country, method = 2) {
  try {
    const res = await fetch(
      `https://api.aladhan.com/v1/timingsByCity?city=${encodeURIComponent(city)}&country=${encodeURIComponent(country)}&method=${method}`
    );
    const data = await res.json();
    if (data.code !== 200) throw new Error('Failed to fetch prayer times');
    const t = data.data.timings;
    return {
      fajr: t.Fajr,
      sunrise: t.Sunrise,
      dhuhr: t.Dhuhr,
      asr: t.Asr,
      maghrib: t.Maghrib,
      isha: t.Isha,
      date: data.data.date.readable,
      hijri: data.data.date.hijri,
    };
  } catch (err) {
    console.error('Error fetching prayer times:', err.message);
    return null;
  }
}

function getNextPrayer(prayers) {
  if (!prayers) return null;
  const now = new Date();
  const prayerNames = ['fajr', 'dhuhr', 'asr', 'maghrib', 'isha'];
  for (const name of prayerNames) {
    const timeStr = prayers[name];
    if (!timeStr) continue;
    const [h, m] = timeStr.split(':').map(Number);
    const prayerTime = new Date();
    prayerTime.setHours(h, m, 0, 0);
    if (prayerTime > now) {
      const diff = prayerTime - now;
      const hours = Math.floor(diff / 3600000);
      const minutes = Math.floor((diff % 3600000) / 60000);
      return { name, time: timeStr, countdown: `${hours}h ${minutes}m` };
    }
  }
  return { name: 'fajr (tomorrow)', time: prayers.fajr, countdown: 'Tomorrow' };
}

function timeToMinutes(timeStr) {
  const [h, m] = timeStr.split(':').map(Number);
  return h * 60 + m;
}

module.exports = { fetchPrayerTimes, getNextPrayer, timeToMinutes };
