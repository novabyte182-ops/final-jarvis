const cron = require('node-cron');
const { PrismaClient } = require('@prisma/client');
const { fetchPrayerTimes } = require('./prayerTimes');
const prisma = new PrismaClient();

let ioInstance;

function init(io) {
  ioInstance = io;

  cron.schedule('* * * * *', async () => {
    try {
      const now = new Date();
      const users = await prisma.user.findMany();

      for (const user of users) {
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        const prayers = await prisma.prayerRecord.findMany({
          where: { userId: user.id, date: { gte: today } },
        });

        const prayerNames = ['fajr', 'dhuhr', 'asr', 'maghrib', 'isha'];
        for (const prayer of prayers) {
          const [h, m] = prayer.time.split(':').map(Number);
          const prayerTime = new Date();
          prayerTime.setHours(h, m, 0, 0);
          const diff = prayerTime - now;

          if (diff > 0 && diff <= 10 * 60 * 1000 && !prayer.completed) {
            ioInstance.emit('notification', {
              userId: user.id,
              type: 'prayer',
              message: `It's time for ${prayer.name} prayer in 10 minutes!`,
            });
          }
        }

        const tasksDue = await prisma.task.findMany({
          where: {
            userId: user.id,
            completed: false,
            dueDate: { lte: new Date(now.getTime() + 24 * 60 * 60 * 1000) },
          },
        });

        if (tasksDue.length > 0) {
          ioInstance.emit('notification', {
            userId: user.id,
            type: 'task',
            message: `You have ${tasksDue.length} task(s) due soon!`,
          });
        }
      }
    } catch (err) {
      console.error('Scheduler error:', err.message);
    }
  });

  cron.schedule('0 0 * * *', async () => {
    try {
      const users = await prisma.user.findMany();
      for (const user of users) {
        const times = await fetchPrayerTimes(user.city, user.country);
        if (times) {
          const today = new Date();
          today.setHours(0, 0, 0, 0);
          for (const name of ['fajr', 'dhuhr', 'asr', 'maghrib', 'isha']) {
            await prisma.prayerRecord.create({
              data: {
                userId: user.id,
                name,
                time: times[name],
                date: today,
              },
            });
          }
          console.log(`Refreshed prayer times for ${user.city}`);
        }
      }
    } catch (err) {
      console.error('Prayer refresh error:', err.message);
    }
  });

  console.log('Jarvis AI Assistant scheduler initialized');
}

module.exports = { init };
