const express = require('express');
const router = express.Router();
const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();
const { chatWithAI } = require('../services/aiAssistant');

function parseIntent(text) {
  const lower = text.toLowerCase().trim();
  const intents = [];

  if (/add task|create task|new task/.test(lower)) {
    const title = lower.replace(/add task|create task|new task/gi, '').trim();
    intents.push({ action: 'add_task', data: { title: title || 'Untitled task' } });
  }

  if (/delete task|remove task/.test(lower)) {
    intents.push({ action: 'delete_task', data: {} });
  }

  if (/mark.*done|complete.*task/.test(lower)) {
    intents.push({ action: 'complete_task', data: {} });
  }

  if (/next prayer|prayer time|when.*(fajr|dhuhr|asr|maghrib|isha)/.test(lower)) {
    intents.push({ action: 'next_prayer', data: {} });
  }

  if (/mark.*(fajr|dhuhr|asr|maghrib|isha)/.test(lower)) {
    const match = lower.match(/(fajr|dhuhr|asr|maghrib|isha)/);
    intents.push({ action: 'mark_prayer', data: { name: match[1] } });
  }

  if (/start pomodoro|start timer|start.*study/.test(lower)) {
    intents.push({ action: 'start_pomodoro', data: {} });
  }

  if (/show tasks|my tasks|list tasks/.test(lower)) {
    intents.push({ action: 'show_tasks', data: {} });
  }

  if (/my schedule|today.*schedule/.test(lower)) {
    intents.push({ action: 'show_schedule', data: {} });
  }

  if (/help|what can you do/.test(lower)) {
    intents.push({ action: 'help', data: {} });
  }

  return intents;
}

router.post('/process', async (req, res) => {
  try {
    const { text, userId } = req.body;
    const intents = parseIntent(text);

    if (intents.length === 0) {
      const reply = await chatWithAI(text, userId);
      return res.json({ response: reply, intents: [] });
    }

    const results = [];
    for (const intent of intents) {
      switch (intent.action) {
        case 'add_task':
          if (userId) {
            const task = await prisma.task.create({
              data: {
                userId,
                title: intent.data.title,
                dueDate: new Date(Date.now() + 24 * 60 * 60 * 1000),
              },
            });
            results.push({ action: 'add_task', result: `Task "${task.title}" added!` });
          }
          break;

        case 'show_tasks':
          if (userId) {
            const tasks = await prisma.task.findMany({
              where: { userId, completed: false },
              take: 5,
            });
            const list = tasks.map(t => `• ${t.title} (${t.priority})`).join('\n');
            results.push({ action: 'show_tasks', result: list || 'No pending tasks!' });
          }
          break;

        case 'next_prayer':
          results.push({ action: 'next_prayer', result: 'Check the Prayer Widget for next prayer time!' });
          break;

        case 'mark_prayer':
          if (userId) {
            const today = new Date();
            today.setHours(0, 0, 0, 0);
            const prayer = await prisma.prayerRecord.findFirst({
              where: { userId, name: intent.data.name, date: { gte: today } },
            });
            if (prayer) {
              await prisma.prayerRecord.update({
                where: { id: prayer.id },
                data: { completed: true },
              });
              results.push({ action: 'mark_prayer', result: `${intent.data.name} marked as done!` });
            } else {
              results.push({ action: 'mark_prayer', result: `Prayer record for ${intent.data.name} not found for today.` });
            }
          }
          break;

        default:
          results.push({ action: intent.action, result: `Action "${intent.action}" recognized.` });
      }
    }

    const response = results.map(r => r.result).join('\n');
    res.json({ response, intents: results });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
