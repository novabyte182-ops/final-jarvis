const express = require('express');
const router = express.Router();
const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();
const { fetchPrayerTimes } = require('../services/prayerTimes');

router.get('/times', async (req, res) => {
  try {
    const { city, country } = req.query;
    const times = await fetchPrayerTimes(city || 'Dhaka', country || 'Bangladesh');
    if (!times) return res.status(500).json({ error: 'Failed to fetch prayer times' });
    res.json(times);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.get('/today/:userId', async (req, res) => {
  try {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const prayers = await prisma.prayerRecord.findMany({
      where: { userId: req.params.userId, date: { gte: today } },
    });

    if (prayers.length === 0) {
      const user = await prisma.user.findUnique({ where: { id: req.params.userId } });
      if (!user) return res.status(404).json({ error: 'User not found' });

      const times = await fetchPrayerTimes(user.city, user.country);
      if (times) {
        const records = [];
        for (const name of ['fajr', 'dhuhr', 'asr', 'maghrib', 'isha']) {
          const record = await prisma.prayerRecord.create({
            data: { userId: user.id, name, time: times[name], date: today },
          });
          records.push(record);
        }
        return res.json(records);
      }
    }
    res.json(prayers);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.patch('/:prayerId', async (req, res) => {
  try {
    const prayer = await prisma.prayerRecord.update({
      where: { id: req.params.prayerId },
      data: { completed: req.body.completed },
    });
    res.json(prayer);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
