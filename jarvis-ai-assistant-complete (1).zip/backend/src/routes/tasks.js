const express = require('express');
const router = express.Router();
const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

router.get('/:userId', async (req, res) => {
  try {
    const { completed, category, priority } = req.query;
    const where = { userId: req.params.userId };
    if (completed !== undefined) where.completed = completed === 'true';
    if (category) where.category = category;
    if (priority) where.priority = priority;

    let tasks = await prisma.task.findMany({
      where,
      orderBy: [{ dueDate: 'asc' }],
    });

    const order = { High: 0, Medium: 1, Low: 2 };
    tasks.sort((a, b) => (order[a.priority] || 1) - (order[b.priority] || 1));

    res.json(tasks);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.post('/', async (req, res) => {
  try {
    const { userId, title, category, priority, dueDate } = req.body;
    const task = await prisma.task.create({
      data: { userId, title, category: category || 'Personal', priority: priority || 'Medium', dueDate: new Date(dueDate) },
    });
    res.status(201).json(task);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.patch('/:taskId', async (req, res) => {
  try {
    const task = await prisma.task.update({
      where: { id: req.params.taskId },
      data: req.body,
    });
    res.json(task);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.delete('/:taskId', async (req, res) => {
  try {
    await prisma.task.delete({ where: { id: req.params.taskId } });
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
