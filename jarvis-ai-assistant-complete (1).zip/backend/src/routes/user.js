const express = require('express');
const router = express.Router();
const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

router.post('/', async (req, res) => {
  try {
    const { userId, name, city, country } = req.body;
    const user = await prisma.user.upsert({
      where: { id: userId || 'default-user' },
      update: {},
      create: {
        id: userId || 'default-user',
        name: name || 'Student',
        city: city || process.env.DEFAULT_CITY || 'Dhaka',
        country: country || process.env.DEFAULT_COUNTRY || 'Bangladesh',
      },
    });
    res.json(user);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.get('/:userId', async (req, res) => {
  try {
    const user = await prisma.user.findUnique({
      where: { id: req.params.userId },
      include: { tasks: true, subjects: true },
    });
    res.json(user || { error: 'User not found' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.patch('/:userId', async (req, res) => {
  try {
    const user = await prisma.user.update({
      where: { id: req.params.userId },
      data: req.body,
    });
    res.json(user);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
