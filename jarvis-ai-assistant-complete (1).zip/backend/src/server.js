const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '../.env') });

const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const cors = require('cors');

const app = express();
app.use(cors({
  origin: '*',
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'x-user-id'],
}));
app.use(express.json());

const server = http.createServer(app);
const io = new Server(server, {
  cors: {
    origin: '*',
    methods: ['GET', 'POST'],
  },
});

app.use('/api/tasks', require('./routes/tasks'));
app.use('/api/prayers', require('./routes/prayers'));
app.use('/api/study', require('./routes/study'));
app.use('/api/voice', require('./routes/voice'));
app.use('/api/user', require('./routes/user'));

io.on('connection', (socket) => {
  console.log(`Client connected: ${socket.id}`);
  socket.on('disconnect', () => console.log(`Client disconnected: ${socket.id}`));
});

const { errorHandler, notFound } = require('./middleware/errorHandler');

require('./services/scheduler').init(io);

app.use(notFound);
app.use(errorHandler);

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => console.log(`Jarvis AI Assistant running on port ${PORT}`));

module.exports = { app, io };
