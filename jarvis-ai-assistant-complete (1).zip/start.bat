@echo off
echo Starting Jarvis AI Assistant...
echo.
echo Backend:  http://localhost:3000
echo Frontend: http://localhost:5173
echo.
echo Press Ctrl+C to stop
echo.

start "Jarvis Backend" cmd /k "cd backend && npm run dev"
timeout /t 3 /nobreak >nul
start "Jarvis Frontend" cmd /k "cd frontend && npm run dev"

echo Both servers starting...
echo Close these windows to stop the servers.
pause
