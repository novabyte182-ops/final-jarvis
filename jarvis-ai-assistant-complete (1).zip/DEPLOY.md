# Jarvis AI Assistant — Cloud Deployment Guide

## Fastest Option: Deploy on Replit (5 minutes)

### Step 1: Create Replit Account
1. Go to https://replit.com
2. Sign up with Google/GitHub (free)

### Step 2: Import Project
1. Click **"+ Create Repl"**
2. Choose **"Import from GitHub"** (push this folder to GitHub first)
   - OR: Choose **"Node.js"** template, then manually upload all files
3. Name it: `jarvis-ai-assistant`

### Step 3: Setup Backend in Replit
1. In Replit Shell, run:
```bash
cd backend
npm install
npx prisma db push
```

2. Go to **Secrets** (left panel) and add:
```
AI_PROVIDER=openrouter
OPENROUTER_KEY=your_key_here
DATABASE_URL=file:./dev.db
NODE_ENV=production
PORT=3000
DEFAULT_CITY=Dhaka
DEFAULT_COUNTRY=Bangladesh
```

3. Click **Run** — backend starts automatically

### Step 4: Setup Frontend
1. Create a **second Repl** (React + Vite template)
2. Upload all frontend files
3. In Shell: `npm install`
4. In **Secrets**, add:
```
VITE_API_URL=https://your-backend-repl.yourusername.repl.co
```
5. Click **Run**

### Step 5: Get AI API Key (FREE)
**Option A — OpenRouter (Recommended)**
1. Go to https://openrouter.ai
2. Sign up (free)
3. Copy your API key
4. Add to backend Secrets as `OPENROUTER_KEY`

**Option B — HuggingFace**
1. Go to https://huggingface.co
2. Sign up → Settings → Access Tokens → Create token
3. Add to backend Secrets as `HF_TOKEN`
4. Set `AI_PROVIDER=huggingface` in Secrets

---

## Alternative: Deploy on Render + Vercel

### Backend → Render (Free)
1. Push code to GitHub
2. Go to https://render.com → New Web Service
3. Connect your repo, set root directory to `backend`
4. Build command: `npm install && npx prisma db push`
5. Start command: `node src/server.js`
6. Add environment variables (same as Replit step 3)

### Frontend → Vercel (Free)
1. Go to https://vercel.com → New Project
2. Import your repo, set root to `frontend`
3. Build command: `npm install && npm run build`
4. Output directory: `dist`
5. Add env var: `VITE_API_URL=https://your-render-app.onrender.com`

---

## Alternative: Deploy on Railway (Free $5 credit)

1. Go to https://railway.app
2. Click **"New Project"** → **"Deploy from GitHub"**
3. Railway auto-detects Node.js
4. Add environment variables in Railway dashboard
5. One-click deploy!

---

## Alternative: Use GitHub Codespaces (No local setup)

1. Push this folder to a GitHub repo
2. Click **"Code"** → **"Create codespace on main"**
3. A full VS Code opens in your browser with Node.js pre-installed
4. Open terminal and run:

```bash
# Backend
cd backend
npm install
cp .env.example .env
npx prisma db push
npm run dev &

# Frontend
cd ../frontend
npm install
npm run dev
```

5. Codespaces gives you preview URLs for both

---

## What You Get After Deploying

| Feature | Status |
|---------|--------|
| Dashboard with greeting & stats | Working |
| Task Manager (Kanban board) | Working |
| Prayer Times (live from Aladhan API) | Working |
| Namaz countdown & tracking | Working |
| Study Planner + Pomodoro timer | Working |
| Voice Commands (browser built-in) | Working |
| AI Chat (free LLM) | Working with API key |
| PWA (installable on phone) | Working |
| Push Notifications | Working |
| Mobile App (Capacitor) | Ready to build |

---

## Troubleshooting

**"AI not responding"** → Check your API key in Secrets
**"Database error"** → Run `npx prisma db push` in backend
**"Voice not working"** → Use Chrome/Edge (Safari has limited support)
**"CORS error"** → Make sure VITE_API_URL points to backend URL
**"Prayer times wrong"** → Change city/country in Settings

---

## Build Mobile APK (Optional)

After web app is live:
```bash
cd frontend
npm run build
cd ../mobile
npm install @capacitor/core @capacitor/cli @capacitor/android
npx cap init
npx cap add android
npx cap sync
npx cap open android
```
This opens Android Studio → Build → Build APK

---

Total cost: **$0/month** on free tiers
