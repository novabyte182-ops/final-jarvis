# Jarvis AI Assistant

## Overview
A multi-functional voice-enabled student productivity web app that serves as a personal AI assistant for university students. Features include task management (Kanban board), prayer (namaz) scheduling, Pomodoro study sessions, AI chat interface, and voice commands.

## Architecture
- **Frontend**: React 18 + Vite + Tailwind CSS, runs on port 5000
- **Backend**: Node.js + Express + Socket.IO, runs on port 3000
- **Database**: SQLite via Prisma ORM (file: `backend/prisma/dev.db`)
- **AI**: HuggingFace / OpenRouter integration (optional API keys)

## Project Structure
```
/
├── frontend/           # React + Vite frontend
│   ├── src/
│   │   ├── components/ # Dashboard, TaskBoard, PrayerWidget, StudyPlanner, ChatInterface, VoiceCommand
│   │   ├── services/   # api.js (fetch + socket.io), voice.js
│   │   └── styles/     # index.css (Tailwind)
│   └── vite.config.js  # Dev server on port 5000, proxies /api and /socket.io -> :3000
├── backend/            # Express + Socket.IO backend
│   ├── src/
│   │   ├── routes/     # tasks, prayers, study, voice, user
│   │   ├── middleware/ # errorHandler.js
│   │   └── services/   # aiAssistant.js, prayerTimes.js, scheduler.js
│   ├── prisma/
│   │   ├── schema.prisma  # SQLite schema (uses SQLITE_URL env var)
│   │   ├── seed.js         # Database seeder
│   │   └── dev.db          # SQLite database file
│   └── .env            # Local env config (AI keys, JWT_SECRET, etc.)
└── mobile/             # Capacitor config (Android/iOS, not used in dev)
```

## Workflows
- **Start application**: `cd frontend && npm run dev` (port 5000, webview)
- **Backend API**: `cd backend && node src/server.js` (port 3000, console)

## Key Environment Variables (Replit Secrets / Shared Env)
- `SQLITE_URL`: `file:/home/runner/workspace/backend/prisma/dev.db` (set as shared env var)
- `PORT`: 3000 (backend)
- `JWT_SECRET`: Set in shared env vars
- `PRAYER_CALC_METHOD`: 2
- `DEFAULT_CITY` / `DEFAULT_COUNTRY`: Dhaka / Bangladesh
- `HF_TOKEN` / `OPENROUTER_KEY`: Optional AI API keys (set via Replit Secrets for AI chat)

## Important Replit-Specific Notes
- The Prisma schema uses `SQLITE_URL` (not `DATABASE_URL`) because Replit manages `DATABASE_URL` for PostgreSQL and it cannot be overridden
- The backend `.env` uses an absolute path for `SQLITE_URL` to avoid CWD issues
- `backend/src/server.js` loads dotenv with an explicit path: `path.join(__dirname, '../.env')`
- Frontend Vite config uses `allowedHosts: true` and `host: '0.0.0.0'` for the Replit proxy
- The frontend static serving from `backend` is disabled in dev (Vite proxies `/api` to backend)
- `backend/src/routes/user.js` uses `/` and `/:userId` routes (not nested `/user/...`)

## Features
1. **Dashboard**: Overview with stats, prayer countdown, recent tasks, live clock
2. **Task Board**: Kanban-style task management with priorities and categories
3. **Prayer Widget**: Daily prayer times (Fajr, Dhuhr, Asr, Maghrib, Isha) with completion tracking — fetched from Aladhan API
4. **Study Planner**: Subject management, study sessions, Pomodoro timer
5. **AI Chat**: Conversational AI via HuggingFace/OpenRouter (requires API key)
6. **Voice Command**: Web Speech API for voice commands
7. **Real-time Notifications**: Socket.IO for prayer and task reminders via cron scheduler
