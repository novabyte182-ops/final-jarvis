@echo off
echo ========================================
echo   Jarvis AI Assistant - Setup Script
echo ========================================
echo.

echo [1/4] Checking Node.js installation...
where node >nul 2>nul
if %errorlevel% neq 0 (
    echo ERROR: Node.js is not installed!
    echo Download it from: https://nodejs.org
    echo.
    pause
    exit /b 1
)
echo Node.js found!
node --version
npm --version
echo.

echo [2/4] Installing backend dependencies...
cd backend
call npm install
if %errorlevel% neq 0 (
    echo ERROR: Backend npm install failed!
    pause
    exit /b 1
)
echo.

echo [3/4] Setting up database...
npx prisma db push
if %errorlevel% neq 0 (
    echo WARNING: Database setup failed. Run: npx prisma db push
    echo.
)
echo.

echo [4/4] Installing frontend dependencies...
cd ..\frontend
call npm install
if %errorlevel% neq 0 (
    echo ERROR: Frontend npm install failed!
    pause
    exit /b 1
)
echo.

echo ========================================
echo   Setup Complete!
echo ========================================
echo.
echo To start Jarvis AI Assistant:
echo.
echo   Terminal 1: cd backend ^&^& npm run dev
echo   Terminal 2: cd frontend ^&^& npm run dev
echo.
echo Then open: http://localhost:5173
echo.
pause
