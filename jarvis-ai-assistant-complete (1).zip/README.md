# Jarvis AI Assistant

A voice-enabled AI assistant for university students that manages daily tasks, schedules 5 daily prayers (namaz), and helps with study planning.

## Features

- Dashboard with greeting, stats, and timeline
- Task Manager with Kanban board (High/Medium/Low priority)
- Namaz Scheduler with live prayer times from Aladhan API
- Study Planner with Pomodoro timer and weekly tracking
- Voice Commands using Web Speech API (STT + TTS)
- AI Chat powered by OpenRouter/HuggingFace free models
- PWA support (installable on mobile)
- Push notifications for prayers and task reminders
- Mobile-ready via Capacitor

## Quick Start

### Local Setup
```bash
npm run install:all
npm run db:push
npm run db:seed

# Terminal 1: Backend
npm run dev:backend

# Terminal 2: Frontend
npm run dev:frontend
```

Open: http://localhost:5173

### Cloud Deployment

#### Replit
1. Import this repo to Replit
2. Shell: `cd backend && npm install && npx prisma db push`
3. Add Secrets: `OPENROUTER_KEY`, `AI_PROVIDER=openrouter`
4. Click Run

#### Render
1. Push to GitHub
2. Import on Render using `render.yaml`
3. Add environment variables
4. Deploy

## Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | React + Vite + Tailwind CSS |
| Backend | Node.js + Express + Socket.IO |
| Database | SQLite (dev) / PostgreSQL (prod) via Prisma |
| AI | OpenRouter (free Llama 3) / HuggingFace |
| Voice | Web Speech API (built-in, free) |
| Prayer Times | Aladhan API (free) |
| Mobile | Capacitor (PWA → APK) |

## API Endpoints

- `POST /api/user` - Create/update user
- `GET /api/tasks/:userId` - List tasks
- `POST /api/tasks` - Create task
- `PATCH /api/tasks/:taskId` - Update task
- `DELETE /api/tasks/:taskId` - Delete task
- `GET /api/prayers/times?city=X&country=Y` - Fetch prayer times
- `GET /api/prayers/today/:userId` - Today's prayer records
- `PATCH /api/prayers/:prayerId` - Mark prayer complete
- `GET /api/study/subjects/:userId` - List subjects
- `POST /api/study/subjects` - Add subject
- `POST /api/study/sessions` - Log study session
- `GET /api/study/stats/:userId` - Weekly stats
- `POST /api/study/chat` - AI chat
- `POST /api/voice/process` - Voice command processing

## Voice Commands

- "Add task study chapter 5 tomorrow"
- "Show my tasks"
- "Next prayer time"
- "Mark dhuhr as done"
- "Start pomodoro"
- "What should I study?"

## Environment Variables

```
AI_PROVIDER=openrouter
OPENROUTER_KEY=your_key
HF_TOKEN=your_token
DATABASE_URL=file:./dev.db
PORT=3000
NODE_ENV=production
DEFAULT_CITY=Dhaka
DEFAULT_COUNTRY=Bangladesh
```

## Cost: $0/month

All services used have generous free tiers:
- Vercel/Replit: Free hosting
- Render: 750 free hours
- Supabase: 500MB database
- OpenRouter: Free Llama 3 model
- Aladhan API: Completely free
- Web Speech API: Built into browser
